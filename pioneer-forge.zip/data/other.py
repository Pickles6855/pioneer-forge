import pygame

pygame.init()

def get_frame(img: pygame.Surface, frame_width: int, frame_height: int, frame_number: int) -> pygame.Surface:
        frame = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
        frame.blit(img, (0, 0), (frame_number * frame_width, 0, frame_width, frame_height))
        return frame