import pygame
from .const import *
from .menu import *
from .policies import *

def change_speed(speed):
    if speed >= 3:
        speed = 1
    else:
        speed += 1
    return speed

def draw_resource_text(display: pygame.Surface, wood, stone, food, population, happiness, day, buildings, food_consumption, mouse_x, mouse_y):
    # Draw resource amounts
    # Wood
    wood_text = PUBLIC_PIXEL_FONT.render_text(str(int(wood)), RESOURCE_TEXT_SIZE, BLACK)
    display.blit(wood_text, (10, 10))
    display.blit(WOOD_ICON_IMG, (20 + wood_text.get_width(), 10))
    
    # Stone
    stone_text = PUBLIC_PIXEL_FONT.render_text(str(int(stone)), RESOURCE_TEXT_SIZE, BLACK)
    display.blit(stone_text, (10, 20 + wood_text.get_height()))
    display.blit(STONE_ICON_IMG, (20 + stone_text.get_width(), 20 + wood_text.get_height()))
    
    # Food
    food_text = PUBLIC_PIXEL_FONT.render_text(str(int(food)), RESOURCE_TEXT_SIZE, BLACK)
    display.blit(food_text, (10, 30 + wood_text.get_height() + stone_text.get_height()))
    display.blit(FOOD_ICON_IMG, (20 + food_text.get_width(), 30 + wood_text.get_height() + stone_text.get_height()))
    
    # Population
    population_text = PUBLIC_PIXEL_FONT.render_text(str(population[0]), RESOURCE_TEXT_SIZE, BLACK)
    display.blit(population_text, (10, 40 + wood_text.get_height() + stone_text.get_height() + food_text.get_height()))
    population_icon_rect = pygame.Rect(20 + population_text.get_width(), 40 + wood_text.get_height() + stone_text.get_height() + food_text.get_height(), RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE)
    if population_icon_rect.collidepoint(mouse_x, mouse_y):
        homeless = population[0] - sum([building.users for building in buildings if building.building_type == 'housing'])
        homeless = 0 if homeless < 0 else homeless
        housing_slots = sum([building.CAPACITY - building.users for building in buildings if building.building_type == 'housing'])
        unemployed = population[1] - sum([building.users for building in buildings if building.building_type == 'business'])
        unemployed = 0 if unemployed < 0 else unemployed
        job_slots = sum([building.max_workers - building.users for building in buildings if building.building_type == 'business'])
        adults_text = PUBLIC_PIXEL_FONT.render_text(f'Adults: {population[1]} / {population[0]}', RESOURCE_TEXT_SIZE - 10, BLACK)
        children_text = PUBLIC_PIXEL_FONT.render_text(f'Children: {population[2]} / {population[0]}', RESOURCE_TEXT_SIZE - 10, BLACK)
        homeless_text_color = DARK_RED if homeless > 0 else BLACK
        unemployed_text_color = DARK_RED if unemployed > 0 else BLACK
        homeless_text = PUBLIC_PIXEL_FONT.render_text(f'Homeless: {homeless} / {population[0]}  ({housing_slots} Houses Available)', RESOURCE_TEXT_SIZE - 10, homeless_text_color)
        unemployed_text = PUBLIC_PIXEL_FONT.render_text(f'Unemployed: {unemployed} / {population[1]}  ({job_slots} Jobs Available)', RESOURCE_TEXT_SIZE - 10, unemployed_text_color)
        display.blit(adults_text, (population_icon_rect.x + RESOURCE_ICON_SIZE + 10, population_icon_rect.y - 100))
        display.blit(children_text, (population_icon_rect.x + RESOURCE_ICON_SIZE + 10, population_icon_rect.y - 90 + adults_text.get_height()))
        display.blit(homeless_text, (population_icon_rect.x + RESOURCE_ICON_SIZE + 10, population_icon_rect.y - 80 + adults_text.get_height() + children_text.get_height()))
        display.blit(unemployed_text, (population_icon_rect.x + RESOURCE_ICON_SIZE + 10, population_icon_rect.y - 70 + adults_text.get_height() + children_text.get_height() + homeless_text.get_height()))
    display.blit(POPULATION_ICON_IMG, population_icon_rect)
    
    # Happiness
    if happiness >= 80:
        happiness_str = 'happy'
        happiness_icon = HAPPY_ICON_IMG
        happiness_text_size = RESOURCE_TEXT_SIZE
    elif happiness >= 60:
        happiness_str = 'mostly happy'
        happiness_icon = HAPPY_ICON_IMG
        happiness_text_size = RESOURCE_TEXT_SIZE - 7
    elif happiness >= 40:
        happiness_str = 'mediocre'
        happiness_icon = OK_HAPPINESS_ICON_IMG
        happiness_text_size = RESOURCE_TEXT_SIZE - 2
    elif happiness >= 20:
        happiness_str = 'somewhat unhappy'
        happiness_icon = UNHAPPY_ICON_IMG
        happiness_text_size = RESOURCE_TEXT_SIZE - 10
    else:
        happiness_str = 'unhappy'
        happiness_icon = UNHAPPY_ICON_IMG
        happiness_text_size = RESOURCE_TEXT_SIZE - 2
        
    happiness_text = PUBLIC_PIXEL_FONT.render_text(happiness_str.title(), happiness_text_size, BLACK)
    display.blit(happiness_text, (10, 50 + wood_text.get_height() + stone_text.get_height() + food_text.get_height() + population_text.get_height()))
    happiness_icon_rect = pygame.Rect(20 + happiness_text.get_width(), 50 + wood_text.get_height() + stone_text.get_height() + food_text.get_height() + population_text.get_height(), RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE)
    
    if happiness_icon_rect.collidepoint(mouse_x, mouse_y):
        homeless = population[0] - sum(building.users for building in buildings if building.building_type == 'housing')
        homeless_happiness = 1 - homeless/population[0]
        unemployed = population[1] - sum(building.users for building in buildings if building.building_type == 'business')
        unemployed_happiness = 1 - unemployed/population[1]
        building_happy_points = 0
        for building in buildings:
            capacity = building.CAPACITY if building.building_type == 'housing' else building.max_workers
            building_happy_points += (building.users/capacity) * building.happy_points
        building_happiness = building_happy_points/sum([building.happy_points for building in buildings])
        food_happiness = 0 if food <= 0 else food_consumption/6
        
        homeless_happiness_text = PUBLIC_PIXEL_FONT.render_text(f'Housing: {int(homeless_happiness * 100)}%', RESOURCE_TEXT_SIZE - 15, BLACK)
        unemployed_happiness_text = PUBLIC_PIXEL_FONT.render_text(f'Jobs: {int(unemployed_happiness * 100)}%', RESOURCE_TEXT_SIZE - 15, BLACK)
        building_happiness_text = PUBLIC_PIXEL_FONT.render_text(f'Buildings: {int(building_happiness * 100)}%', RESOURCE_TEXT_SIZE - 15, BLACK)
        food_happiness_text = PUBLIC_PIXEL_FONT.render_text(f'Food: {int(food_happiness * 100)}%', RESOURCE_TEXT_SIZE - 15, BLACK)
        happiness_percent_text = PUBLIC_PIXEL_FONT.render_text(f'Total: {happiness}%', RESOURCE_TEXT_SIZE - 15, BLACK)
        
        display.blit(homeless_happiness_text, (happiness_icon_rect.x + RESOURCE_ICON_SIZE + 10, happiness_icon_rect.y - 100))
        display.blit(unemployed_happiness_text, (happiness_icon_rect.x + RESOURCE_ICON_SIZE + 10, happiness_icon_rect.y - 90 + homeless_happiness_text.get_height()))
        display.blit(building_happiness_text, (happiness_icon_rect.x + RESOURCE_ICON_SIZE + 10, happiness_icon_rect.y - 80 + homeless_happiness_text.get_height() + unemployed_happiness_text.get_height()))
        display.blit(food_happiness_text, (happiness_icon_rect.x + RESOURCE_ICON_SIZE + 10, happiness_icon_rect.y - 70 + homeless_happiness_text.get_height() + unemployed_happiness_text.get_height() + building_happiness_text.get_height()))
        display.blit(happiness_percent_text, (happiness_icon_rect.x + RESOURCE_ICON_SIZE + 10, happiness_icon_rect.y - 60 + homeless_happiness_text.get_height() + unemployed_happiness_text.get_height() + building_happiness_text.get_height() + food_happiness_text.get_height()))

        
    display.blit(happiness_icon, happiness_icon_rect)
    
    # Day Number
    day_text = PUBLIC_PIXEL_FONT.render_text(f'Day {day}', RESOURCE_TEXT_SIZE, BLACK)
    display.blit(day_text, (10, 60 + wood_text.get_height() + stone_text.get_height() + food_text.get_height() + population_text.get_height() + happiness_text.get_height()))

    return display




def handle_hud(display:pygame.Surface, pause_button: Button, speed, speed_button: Button, policies_button: Button, achievments_button: Button, events, policies_menu, achievments_menu, food_consumption, population_growth, change_policies_buttons, current_music_track, world_data, buildings, wood, stone, food, population, happiness, day, mouse_x, mouse_y, achievments):
    # Policies menu
    if policies_menu:
        display, population_growth, food_consumption, policies_menu, change_policies_buttons = handle_policies_menu(display, population_growth, food_consumption, policies_menu, events, change_policies_buttons, mouse_x, mouse_y)
    else:
        for button in change_policies_buttons:
            button.rect.x = -100
            button.rect.y = -100

    # Buttons
    reload_world = False
    if pause_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        save_data(world_data, buildings, wood, stone, food, population, happiness, day, population_growth, food_consumption, achievments)
        display, current_music_track, reload_world = main_menu(display, current_music_track)
    display.blit(pause_button.display_img, pause_button.rect)
    
    if speed_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        speed = change_speed(speed)

    # Speed Button
    if speed_button.display_img == 'hover image':
        speep_button_frame = 1
    else:
        speep_button_frame = 0
    if speed == 1:
        display.blit(get_frame(SPEED_1_BUTTON_IMG, BUTTON_SIZE[0]//2, BUTTON_SIZE[1], speep_button_frame), speed_button.rect)
    elif speed == 2:
        display.blit(get_frame(SPEED_2_BUTTON_IMG, BUTTON_SIZE[0]//2, BUTTON_SIZE[1], speep_button_frame), speed_button.rect)
    elif speed == 3:
        display.blit(get_frame(SPEED_3_BUTTON_IMG, BUTTON_SIZE[0]//2, BUTTON_SIZE[1], speep_button_frame), speed_button.rect)

    # Policies Button
    if policies_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        achievments_menu = False
        policies_menu = not policies_menu
    display.blit(policies_button.display_img, policies_button.rect)
    
    # Achievments Button
    if achievments_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        policies_menu = False
        achievments_menu = not achievments_menu
    display.blit(achievments_button.display_img, achievments_button.rect)

    return display, pause_button, speed_button, policies_button, achievments_button, speed, policies_menu, achievments_menu, population_growth, food_consumption, change_policies_buttons, current_music_track, reload_world
