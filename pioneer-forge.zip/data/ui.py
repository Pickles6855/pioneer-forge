import pygame

pygame.init()

class CustomFont:
    def __init__(self, font_path: str):
        self.font_path = font_path

    def render_text(self, text: str, size: int, color: pygame.Color or tuple, antialias: bool=True) -> pygame.Surface:
        font = pygame.font.Font(self.font_path, size)
        
        text = str(text)
        
        if text.count('\n') > 0:
            lines_str = text.split('\n')
        else:
            lines_str = [text]
        lines = [font.render(str(line), antialias, color) for line in lines_str]
        
        return_text = pygame.Surface((max([line.get_width() for line in lines]), (size) * len(lines)), pygame.SRCALPHA)
        
        [return_text.blit(line, (return_text.get_width()//2 - line.get_width()//2, indx * size)) for indx, line in enumerate(lines)]
        return return_text

class Button:
    def __init__(self, img, hover_img, x, y, width, height, click_func=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.img = img
        self.hover_img = hover_img
        self.display_img = self.img
        self.click_func = click_func

    def update(self, events=pygame.event.get(), offset_x=0, offset_y=0, mouse_x=pygame.mouse.get_pos()[0], mouse_y=pygame.mouse.get_pos()[1]) -> bool:
        if pygame.Rect(self.rect.x - offset_x, self.rect.y - offset_y, self.rect.width, self.rect.height).collidepoint(mouse_x, mouse_y):
            self.display_img = self.hover_img
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if self.click_func != None:
                        self.click_func()
                    return True
        else:
            self.display_img = self.img

    def hover_overlay(reg_img: pygame.Surface, overlay_img: pygame.Surface) -> pygame.Surface:
        overlay = pygame.Surface(reg_img.get_size(), pygame.SRCALPHA)
        overlay.blit(reg_img, (0, 0))
        overlay.blit(overlay_img, (0, 0))
        overlay.set_colorkey((0, 0, 0))
        return overlay