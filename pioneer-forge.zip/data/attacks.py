import pygame
from .const import *

def handle_attack(display: pygame.Surface, attackers, buildings, attack_text_visible, days_since_last_attack, events):
    for event in events:
        if event.type == ATTACK_TEXT_FLASH_EVENT:
            if attack_text_visible >= 2:
                attack_text_visible = 0
            else:
                attack_text_visible += 1
            
    if attack_text_visible > 0:
        attack_text = PUBLIC_PIXEL_FONT.render_text('Under Attack!', 35, DARK_RED)
        display.blit(attack_text, (WIDTH//2 - attack_text.get_width()//2, 10))
        
        attackers_text = PUBLIC_PIXEL_FONT.render_text(f'Attackers Remaining: {attackers}', 15, DARK_RED)   
        display.blit(attackers_text, (WIDTH//2 - attackers_text.get_width()//2, 25 + attack_text.get_height())) 

    under_attack = True
    if attackers <= 0:
        days_since_last_attack = 0
        under_attack = False
    
    return display, attackers, under_attack, attack_text_visible, days_since_last_attack