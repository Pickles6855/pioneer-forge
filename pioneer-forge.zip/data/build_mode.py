import pygame
from .const import *
from .buildings import *

def handle_build_mode(display: pygame.Surface, selected_building, available_buildings: list[Building], buildings: list[Building], world_data, events, offset_x, offset_y, placed_building_x, placed_building_y, wood, stone, food, right_arrow_button: Button, left_arrow_button: Button, mouse_x, mouse_y):
    build_mode = True
            
    for event in events:
        if event.type == pygame.KEYDOWN:
            # Scroll between available buildings
            # Left
            if event.key == pygame.K_a:
                if selected_building > 0:
                    selected_building -= 1
                else:
                    selected_building = len(available_buildings) - 1
            # Right
            elif event.key == pygame.K_d:
                if selected_building < len(available_buildings) - 1:
                    selected_building += 1
                else:
                    selected_building = 0

            if event.key == pygame.K_ESCAPE:
                build_mode = False

            # Place building
            cost_is_met = wood >= available_buildings[selected_building].cost['wood'] and stone >= available_buildings[selected_building].cost['stone'] and food >= available_buildings[selected_building].cost['food']
            if (event.key == pygame.K_RETURN or event.key == pygame.K_w or event.key == pygame.K_s) and cost_is_met:
                build_mode = False
                
                PLACE_BUILDING_SOUND.play()
                
                world_data[placed_building_y][placed_building_x] = 2.1
                new_building = available_buildings[selected_building]
                
                wood -= new_building.cost['wood']
                stone -= new_building.cost['stone']
                food -= new_building.cost['food']

                buildings.append(new_building.create_building(placed_building_x, placed_building_y))
                
    build_mode_overlay = pygame.Surface((WIDTH, HEIGHT))
    build_mode_overlay.set_alpha(120)
    build_mode_overlay.fill(BLACK)
    display.blit(build_mode_overlay, (0, 0))

    # Scroll buttons
    if right_arrow_button.update(events,mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if selected_building < len(available_buildings) - 1:
            selected_building += 1
        else:
            selected_building = 0
    display.blit(right_arrow_button.display_img, right_arrow_button.rect)
    
    if left_arrow_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if selected_building > 0:
            selected_building -= 1
        else:
            selected_building = len(available_buildings) - 1
    display.blit(left_arrow_button.display_img, left_arrow_button.rect)

    for indx, building in enumerate(available_buildings):
        if indx == selected_building:
            display.blit(pygame.transform.scale(building.base_img, (building.rect.width * 5, building.rect.height * 5)), (
                WIDTH//2 - building.rect.width * 2.5, HEIGHT//2 - building.rect.height * 2.5))
            
            display.blit(pygame.transform.scale(building.icon_img, (building.icon_img.get_width() * 4, building.icon_img.get_height() * 4)), (
                WIDTH//2 - building.icon_img.get_width() * 2, HEIGHT//2 - building.icon_img.get_height() * 2))
            
            # Building Name
            building_name_text = PUBLIC_PIXEL_FONT.render_text(building.name, 60, WHITE)
            display.blit(building_name_text, (WIDTH//2 - building_name_text.get_width()//2, 75))
            
            # Building Description
            building_desc_text_str = building.desc
            y = HEIGHT//2 + building.rect.height * 2.5 + 20
            for line in building_desc_text_str.split('\n'):
                line_text = PUBLIC_PIXEL_FONT.render_text(line, 25, WHITE)
                display.blit(line_text, (WIDTH//2 - line_text.get_width()//2, y))
                y += 10 + line_text.get_height()
                
            # Building Cost
            # Wood
            wood_text_color = LIGHT_RED if building.cost['wood'] > wood else WHITE
            wood_text = PUBLIC_PIXEL_FONT.render_text(building.cost['wood'], 30, wood_text_color)
            wood_surf = pygame.Surface((wood_text.get_width() + 20 + wood_text.get_height(), wood_text.get_height() + 10), pygame.SRCALPHA)
            wood_surf.blit(wood_text, (0, 5))
            wood_surf.blit(pygame.transform.scale(WOOD_ICON_IMG, (wood_text.get_height() + 10, wood_text.get_height() + 10)).convert_alpha(), (wood_surf.get_width() - wood_text.get_width() - 10, 0))
            
            # Stone
            stone_text_color = LIGHT_RED if building.cost['stone'] > stone else WHITE
            stone_text = PUBLIC_PIXEL_FONT.render_text(building.cost['stone'], 30, stone_text_color)
            stone_surf = pygame.Surface((stone_text.get_width() + 20 + stone_text.get_height(), stone_text.get_height() + 10), pygame.SRCALPHA)
            stone_surf.blit(stone_text, (0, 5))
            stone_surf.blit(pygame.transform.scale(STONE_ICON_IMG, (stone_text.get_height() + 10, stone_text.get_height() + 10)).convert_alpha(), (stone_surf.get_width() - stone_text.get_width() - 10, 0))
            
            # Food
            food_text_color = LIGHT_RED if building.cost['food'] > food else WHITE
            food_text = PUBLIC_PIXEL_FONT.render_text(building.cost['food'], 30, food_text_color)
            food_surf = pygame.Surface((food_text.get_width() + 20 + food_text.get_height(), food_text.get_height() + 10), pygame.SRCALPHA)
            food_surf.blit(food_text, (0, 5))
            food_surf.blit(pygame.transform.scale(FOOD_ICON_IMG, (food_text.get_height() + 10, food_text.get_height() + 10)).convert_alpha(), (food_surf.get_width() - food_text.get_width() - 10, 0))
            
            display.blit(stone_surf, (WIDTH//2 - stone_surf.get_width()//2, 125 + building_name_text.get_height()))
            display.blit(wood_surf, (WIDTH//2 - stone_surf.get_width()//2 - 50 - stone_surf.get_width(), 125 + building_name_text.get_height()))
            display.blit(food_surf, (WIDTH//2 + stone_text.get_width()//2 + 50, 125 + building_name_text.get_height()))


    return display, selected_building, buildings, world_data, build_mode, wood, stone, food, right_arrow_button, left_arrow_button

