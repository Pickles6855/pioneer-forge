import pygame
from .const import *
from .generate_world import *
from .ui import *

def options_menu(display: pygame.Surface, in_options, return_button: Button, events, options_menu_title_text, reset_world_button: Button, mouse_x, mouse_y):
    if return_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        in_options = False
    display.blit(return_button.display_img, return_button.rect)
    
    display.blit(options_menu_title_text, (WIDTH//2 - options_menu_title_text.get_width()//2, 35))
    
    reload_world = False
    if reset_world_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        generate_world()
        reload_world = True
        in_options = False
    display.blit(reset_world_button.display_img, reset_world_button.rect)
    
    return display, in_options, return_button, reset_world_button, reload_world


def help_menu(display: pygame.Surface, in_help, return_button: Button, events, help_menu_texts: list[pygame.Surface], help_menu_title_text: pygame.Surface, mouse_x, mouse_y):
    if return_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        in_help = False
    display.blit(return_button.display_img, return_button.rect)
    
    display.blit(help_menu_title_text, (WIDTH//2 - help_menu_title_text.get_width()//2, 35))
    
    for indx, line in enumerate(help_menu_texts):
        display.blit(line, (WIDTH//2 - line.get_width()//2, 100 + help_menu_title_text.get_height() + indx * (15 + line.get_height())))
    
    return display, in_help, return_button



def main_menu(display: pygame.Surface, current_music_track):
    fps_clock = pygame.time.Clock()
    
    # Main menu buttons
    play_button_text = (PUBLIC_PIXEL_FONT.render_text('Play', 50, WHITE), PUBLIC_PIXEL_FONT.render_text('>Play<', 50, LIGHT_GREY))
    play_button = Button(play_button_text[0], play_button_text[1], 50, 
                         HEIGHT//2 - play_button_text[0].get_height()//2 - (play_button_text[0].get_height() * 2) - 60, play_button_text[0].get_width(), play_button_text[0].get_height(), play_button_sound
                        )
    options_button_text = (PUBLIC_PIXEL_FONT.render_text('Options', 50, WHITE), PUBLIC_PIXEL_FONT.render_text('>Options<', 50, LIGHT_GREY))
    options_button = Button(options_button_text[0], options_button_text[1], 50, 
                         HEIGHT//2 - options_button_text[0].get_height()//2 - options_button_text[0].get_height() - 30, options_button_text[0].get_width(), play_button_text[0].get_height(), play_button_sound
                        )
    help_button_text = (PUBLIC_PIXEL_FONT.render_text('Help', 50, WHITE), PUBLIC_PIXEL_FONT.render_text('>Help<', 50, LIGHT_GREY))
    help_button = Button(help_button_text[0], help_button_text[1], 50, 
                         HEIGHT//2 - help_button_text[0].get_height()//2, help_button_text[0].get_width(), help_button_text[0].get_height(), play_button_sound
                        )
    quit_button_text = (PUBLIC_PIXEL_FONT.render_text('Quit', 50, WHITE), PUBLIC_PIXEL_FONT.render_text('>Quit<', 50, LIGHT_GREY))
    quit_button = Button(quit_button_text[0], quit_button_text[1], 50, 
                         HEIGHT//2 + quit_button_text[0].get_height()//2 + 30, quit_button_text[0].get_width(), quit_button_text[0].get_height(), play_button_sound
                        )
    
    # Options and help return button
    return_button_text = (PUBLIC_PIXEL_FONT.render_text(' Main Menu ', 50, WHITE), PUBLIC_PIXEL_FONT.render_text('>Main Menu<', 50, LIGHT_GREY))
    return_button = Button(return_button_text[0], return_button_text[1], WIDTH//2 - return_button_text[0].get_width()//2,
                           HEIGHT - 70 - return_button_text[0].get_height(), return_button_text[0].get_width(), return_button_text[0].get_height(), play_button_sound
                          )
    
    game_version_text = PUBLIC_PIXEL_FONT.render_text('Pioneer Forge v1.2', 20, WHITE)
    credits_text = PUBLIC_PIXEL_FONT.render_text('Made by Pickles6855', 20, WHITE)
    
    # Help menu text
    help_menu_text_str = [
        'Manage your civilization by building',
        'structures and keeping your people',
        'happy. Use WASD to move and hold',
        'SHIFT to go faster. Build structures',
        'by clicking on a tile, selecting a',
        'structure with A and D, and placing',
        'it with ENTER. You can veiw building',
        'info by clicking on its icon and',
        'destroy it by pressing DELETE while',
        'its selected. Manage your resources',
        'and keep your population happy to make',
        'them more productive. Good luck!'
    ]
    help_menu_texts = [PUBLIC_PIXEL_FONT.render_text(line, 30, WHITE) for line in help_menu_text_str]
    help_menu_title_text = PUBLIC_PIXEL_FONT.render_text('Help', 50, WHITE)
    
    # Options menu buttons
    options_menu_title_text = PUBLIC_PIXEL_FONT.render_text('Options', 50, WHITE)
    
    reset_world_button_text = (PUBLIC_PIXEL_FONT.render_text(' Reset Save File ', 40, WHITE), PUBLIC_PIXEL_FONT.render_text('>Reset Save File<', 40, LIGHT_GREY))
    reset_world_button = Button(reset_world_button_text[0], reset_world_button_text[1], WIDTH//2 - reset_world_button_text[0].get_width()//2,
                                HEIGHT - 250 - return_button_text[0].get_height() - reset_world_button_text[0].get_height(), reset_world_button_text[0].get_width(),
                                reset_world_button_text[0].get_height(), play_button_sound
                               )
    
    in_options = False
    in_help = False
    reload_world = False
    
    while True:
        fps_clock.tick(FPS)
        mouse_pos = pygame.mouse.get_pos()
        mouse_x = int(mouse_pos[0] * WIDTH / WINDOW.get_width())
        mouse_y = int(mouse_pos[1] * HEIGHT / WINDOW.get_height())
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        current_music_track = handle_music(current_music_track)
        
        display.blit(MAIN_MENU_BG, (0, 0))
        bg_overlay = pygame.Surface((WIDTH, HEIGHT))
        bg_overlay.fill(BLACK)
        bg_overlay.set_alpha(100)
        display.blit(bg_overlay, (0, 0))
        
        if in_options:
            display, in_options, return_button, reset_world_button, reload_world = options_menu(display, in_options, return_button, events, options_menu_title_text, reset_world_button, mouse_x, mouse_y)
        elif in_help:
            display, in_help, return_button = help_menu(display, in_help, return_button, events, help_menu_texts, help_menu_title_text, mouse_x, mouse_y)
        else:
            display.blit(LOGO_IMG, (WIDTH - 50 - LOGO_IMG.get_width(), HEIGHT//2 - LOGO_IMG.get_height()//2))
            
            if play_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
                return display, current_music_track, reload_world
            
            
            display.blit(play_button.display_img, play_button.rect)
            
            if options_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
                in_options = True
            display.blit(options_button.display_img, options_button.rect)
            
            if help_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
                in_help = True
            display.blit(help_button.display_img, help_button.rect)
            
            if quit_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
                pygame.quit()
                quit()
            display.blit(quit_button.display_img, quit_button.rect)
            
            display.blit(game_version_text, (10, HEIGHT - 10 - game_version_text.get_height()))
            display.blit(credits_text, (WIDTH - 10 - credits_text.get_width(), HEIGHT - 10 - credits_text.get_height()))
            
        
        draw_scaled_display(display)