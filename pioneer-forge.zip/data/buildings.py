import pygame
from .const import *
from .ui import *
from .other import *

def get_building(buildings, grid_x, grid_y):
    for building in buildings:
        if building.grid_x == grid_x and building.grid_y == grid_y:
            return building
    return buildings[0]

class Building:
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, width, height, name, building_type, happy_points, desc, cost):
        self.name = name
        self.base_img_path = base_img_path
        self.icon_img_path = icon_img_path
        self.base_img = pygame.transform.scale(pygame.image.load(self.base_img_path), (width, height))
        self.icon_img = pygame.transform.scale(pygame.image.load(self.icon_img_path), (width//2, height//2)).convert_alpha()
        self.grid_x = grid_x
        self.grid_y = grid_y
        self.rect = pygame.Rect(grid_x * TILE_SIZE, grid_y * TILE_SIZE, width, height)
        self.icon_button = Button(self.icon_img, Button.hover_overlay(self.icon_img, BUILDING_ICON_HOVER_OVERLAY_IMG), 
                                  self.rect.x + self.rect.width//2 - self.rect.width//4, self.rect.y + self.rect.height//2 - self.rect.height//4,
                                  self.rect.width//2, self.rect.height//2, play_button_sound
                                )
        self.building_type = building_type
        self.menu_open = False
        self.happy_points = happy_points
        self.desc = desc
        self.cost = cost
        
    def update(self, display, offset_x, offset_y, events, mouse_x, mouse_y):
        if self.icon_button.update(events, offset_x, offset_y, mouse_x=mouse_x, mouse_y=mouse_y):
            self.menu_open = not self.menu_open
            
        draw_pos = (self.rect.x - offset_x, self.rect.y - offset_y)
        display.blit(self.base_img, draw_pos)
        display.blit(self.icon_button.display_img, (self.icon_button.rect.x - offset_x, self.icon_button.rect.y - offset_y))
        
        delete_self = False
        if self.menu_open == True:
            # Building info (Residents/workers, name, etc.)
            for event in events:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_w or event.key == pygame.K_a or event.key == pygame.K_s or event.key == pygame.K_d or event.key == pygame.K_RETURN:
                        self.menu_open = False
                    if (event.key == pygame.K_e or event.key == pygame.K_PLUS or event.key == pygame.K_EQUALS) and self.building_type == 'business':
                        if self.max_workers >= self.CAPACITY:
                            self.max_workers = 0
                        else:
                            self.max_workers += 1
                    elif (event.key == pygame.K_q or event.key == pygame.K_MINUS) and self.building_type == 'business':
                        if self.max_workers <= 0:
                            self.max_workers = self.CAPACITY
                        else:
                            self.max_workers -= 1   
                            
                    if event.key == pygame.K_BACKSPACE:
                        delete_self = True
            
            
            users_type = 'residents' if self.building_type == 'housing' else 'workers'
            max_users = self.CAPACITY if self.building_type == 'housing' else self.max_workers
            users_text = PUBLIC_PIXEL_FONT.render_text(f'{self.users} / {max_users} {users_type}', RESOURCE_TEXT_SIZE - 10, WHITE)
            users_text_pos = (self.rect.x - offset_x + self.rect.width//2 - users_text.get_width()//2, self.rect.y - offset_y - users_text.get_height() - 20)
            
            name_text = PUBLIC_PIXEL_FONT.render_text(self.name, RESOURCE_TEXT_SIZE, WHITE)
            name_text_pos = (self.rect.x - offset_x + self.rect.width//2 - name_text.get_width()//2, self.rect.y - offset_y - users_text.get_height() - name_text.get_height() - 30)
            
            building_info = [name_text, name_text_pos, users_text, users_text_pos]
        else:
            building_info = []
    
        
        return display, self.menu_open, building_info, delete_self

    def action(self, wood, stone, food, population, buildings, attackers):
        return wood, stone, food, attackers



####################
class House(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, CAPACITY, name, happy_points, desc, cost):
        self.CAPACITY = CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'housing', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, House
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, CAPACITY, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = House(base_img_path, icon_img_path, grid_x, grid_y, CAPACITY, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return House(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.CAPACITY, self.name, self.happy_points, self.desc, self.cost)
    
    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        return wood, stone, food, attackers




####################
class Farm(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 5
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Farm
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Farm(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Farm(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)
    
    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        for worker in range(self.users):
            food += happiness/100
        return wood, stone, food, attackers
    



####################
class Mine(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 5
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Mine
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Mine(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Mine(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)
    
    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        for worker in range(self.users):
            stone += happiness/100 if [building for building in buildings if type(building) == Blacksmith and building.users > 0] == [] else happiness/100 * 2
        return wood, stone, food, attackers



####################
class Woodcutter(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 5
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Woodcutter
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Woodcutter(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Woodcutter(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)

    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        for worker in range(self.users):
            wood += happiness/100 if [building for building in buildings if type(building) == Blacksmith and building.users > 0] == [] else happiness/100 * 2
        return wood , stone, food, attackers




####################
class Bakery(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 2
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Bakery
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Bakery(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Bakery(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)

    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        for worker in range(self.users):
            food += happiness/100
        return wood , stone, food, attackers
    
    
    
    
####################
class Blacksmith(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 2
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Blacksmith
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Blacksmith(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Blacksmith(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)

    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        return wood, stone, food, attackers
    
    
    
    
 ####################   
class Tavern(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 2
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Tavern
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Tavern(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Tavern(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)

    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        return wood, stone, food, attackers



####################
class Fortress(Building):
    def __init__(self, base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost):
        self.CAPACITY = 3
        self.max_workers = self.CAPACITY
        self.users = 0
        super().__init__(base_img_path, icon_img_path, grid_x, grid_y, TILE_SIZE, TILE_SIZE, name, 'business', happy_points, desc, cost)

    def get_save_obj(self):
        return (
            self.base_img_path, self.icon_img_path,
            self.grid_x, self.grid_y, self.rect.width, self.rect.height,
            self.CAPACITY, self.users, self.name, self.happy_points, self.desc, self.cost, Fortress
        )

    def load_save_obj(save_obj):
        base_img_path, icon_img_path, grid_x, grid_y, width, height, _, users, name, happy_points, desc, cost, _ = save_obj
        new_obj = Fortress(base_img_path, icon_img_path, grid_x, grid_y, name, happy_points, desc, cost)
        new_obj.rect.width = width
        new_obj.rect.height = height
        new_obj.users = users
        return new_obj
    
    def create_building(self, grid_x, grid_y):
        return Fortress(self.base_img_path, self.icon_img_path, grid_x, grid_y, self.name, self.happy_points, self.desc, self.cost)

    def action(self, wood, stone, food, population, buildings, happiness, attackers):
        if attackers > 0:
            for i in range(self.users):
                attackers -= 1 if attackers > 0 else 0
        return wood, stone, food, attackers
    