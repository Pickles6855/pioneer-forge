import pickle
import pygame
import os
from .ui import *
from .other import get_frame

pygame.init()

# Constants
# Aspect ratio must be 4/3
WIDTH, HEIGHT = 1200, 900
SCREEN_WIDTH, SCREEN_HEIGHT = 800, 600
FPS = 60
DIR = os.path.dirname(os.path.abspath(__file__))
TILE_SIZE = 100
RESOURCE_ICON_SIZE = 40
RESOURCE_TEXT_SIZE = 35
BUTTON_SIZE = (100, 52)
ACHIEVMENTS_SIZE = (200, 200)
ACHIEVMENT_POP_UP_SIZE = (BUTTON_SIZE[0]//2, BUTTON_SIZE[0]//2)
MOVE_VEL = 8
# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
LIGHT_GREY = (220, 220, 220)
DARK_RED = (150, 25, 25)
LIGHT_RED = (255, 150, 150)

NO_PLACE_RECT = pygame.Rect(WIDTH - BUTTON_SIZE[0] * 2 - 60, 0, BUTTON_SIZE[0] * 2 + 60, 30 + BUTTON_SIZE[1])

def load_path(*folders: str, parent_dir: str=os.path.join(DIR, 'assets')):
    return os.path.join(parent_dir, *folders)

# Setup Window
WINDOW = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption('Pioneer Forge v1.2')

# Events
DAY_TICK_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(DAY_TICK_EVENT, 6000)

BUILDING_ACTION_EVENT = pygame.USEREVENT + 2
pygame.time.set_timer(BUILDING_ACTION_EVENT, 3000)

ATTACK_TEXT_FLASH_EVENT = pygame.USEREVENT + 3
pygame.time.set_timer(ATTACK_TEXT_FLASH_EVENT, 300)


# Load Assets
LOGO_IMG = pygame.transform.scale(pygame.image.load(load_path('icon.png')), (700, 700))
MAIN_MENU_BG = pygame.transform.scale(pygame.image.load(load_path('menu_bg.png')), (HEIGHT * 2, HEIGHT))
pygame.display.set_icon(LOGO_IMG)
# Terrain
# Grass Images
GRASS_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'grass.png')), (TILE_SIZE, TILE_SIZE))
GRASS_DAISY_FLOWERS_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'grass_daisy_flowers.png')), (TILE_SIZE, TILE_SIZE))
GRASS_RED_FLOWERS_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'grass_red_flowers.png')), (TILE_SIZE, TILE_SIZE))
GRASS_YELLOW_FLOWERS_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'grass_yellow_flowers.png')), (TILE_SIZE, TILE_SIZE))
# Trees
TREE_1_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'tree_1.png')), (TILE_SIZE//2, TILE_SIZE//2))
TREE_2_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'tree_2.png')), (TILE_SIZE//2, TILE_SIZE//2))
TREE_3_IMG = pygame.transform.scale(pygame.image.load(load_path('terrain', 'tree_3.png')), (TILE_SIZE//2, TILE_SIZE//2))

# Resource Icons
WOOD_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'wood_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
STONE_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'stone_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
FOOD_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'food_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
POPULATION_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'person_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
# Happiness Icons
HAPPY_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'happy_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
OK_HAPPINESS_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'ok_happiness_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))
UNHAPPY_ICON_IMG = pygame.transform.scale(pygame.image.load(load_path('icons', 'unhappy_icon.png')), (RESOURCE_ICON_SIZE, RESOURCE_ICON_SIZE))

# Buildings
# Icons
BUILDING_ICON_HOVER_OVERLAY_IMG = pygame.transform.scale(pygame.image.load(load_path('buildings', 'icon_hover_overlay.png')), (TILE_SIZE//2, TILE_SIZE//2)).convert_alpha()


# Buttons
# Game Speed
SPEED_1_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'speed_1.png')), BUTTON_SIZE).convert_alpha()
SPEED_2_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'speed_2.png')), BUTTON_SIZE).convert_alpha()
SPEED_3_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'speed_3.png')), BUTTON_SIZE).convert_alpha()
PAUSE_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'pause.png')), BUTTON_SIZE).convert_alpha()
POLICIES_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'policies.png')), BUTTON_SIZE).convert_alpha()
PLUS_BUTTON_IMG = get_frame(pygame.transform.scale(pygame.image.load(load_path('buttons', 'plus_and_minus.png')), (BUTTON_SIZE[0], BUTTON_SIZE[1]//2)).convert_alpha(), BUTTON_SIZE[0]//2, BUTTON_SIZE[1]//2, 0).convert_alpha()
MINUS_BUTTON_IMG = get_frame(pygame.transform.scale(pygame.image.load(load_path('buttons', 'plus_and_minus.png')), (BUTTON_SIZE[0], BUTTON_SIZE[1]//2)).convert_alpha(), BUTTON_SIZE[0]//2, BUTTON_SIZE[1]//2, 1).convert_alpha()
RIGHT_ARROW_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'arrows.png')), (BUTTON_SIZE[0], BUTTON_SIZE[0]))
LEFT_ARROW_BUTTON_IMG = pygame.transform.flip(RIGHT_ARROW_BUTTON_IMG, True, False)
ACHIEVMENTS_BUTTON_IMG = pygame.transform.scale(pygame.image.load(load_path('buttons', 'achievments.png')), BUTTON_SIZE).convert_alpha()

# Fonts
PUBLIC_PIXEL_FONT = CustomFont(load_path('public_pixel_font', 'PublicPixel-z84yD.ttf'))

# Sounds
BUTTON_SOUND = pygame.mixer.Sound(load_path('sounds', 'button.wav'))
PLACE_BUILDING_SOUND = pygame.mixer.Sound(load_path('sounds', 'place_building.wav'))
DESTROY_BUILDING_SOUND = pygame.mixer.Sound(load_path('sounds', 'destroy_building.wav'))
ATTACK_CHANNEL = pygame.mixer.Channel(1)
ATTACK_SOUND = pygame.mixer.Sound(load_path('sounds', 'attack.wav'))
BUTTON_SOUND.set_volume(0.8)
PLACE_BUILDING_SOUND.set_volume(0.8)
DESTROY_BUILDING_SOUND.set_volume(0.8)
ATTACK_SOUND.set_volume(0.8)
# Music
MUSIC_TRACKS = [load_path('music', track) for track in os.listdir(load_path('music')) if track != '.DS_Store']

def play_button_sound():
    BUTTON_SOUND.play()
    
def handle_music(current_music_track):
    # Reset music track
    if pygame.mixer.music.get_busy() == False and ATTACK_CHANNEL.get_busy() == False:
        if current_music_track + 1 >= len(MUSIC_TRACKS):
            current_music_track = 0
        else:
            current_music_track += 1
        
        pygame.mixer.music.load(MUSIC_TRACKS[current_music_track])
        pygame.mixer.music.set_volume(0.1)
        pygame.mixer.music.play()
        
    
    return current_music_track

def save_data(world_data, buildings, wood, stone, food, population, happiness, day, population_growth, food_consumption, achievments):
    buildings_save = [building.get_save_obj() for building in buildings]
    with open(load_path('save.pkl', parent_dir=DIR), 'wb') as save_file:
        pickle.dump(world_data, save_file); pickle.dump(buildings_save, save_file); pickle.dump(wood, save_file)
        pickle.dump(stone, save_file); pickle.dump(food, save_file); pickle.dump(population, save_file)
        pickle.dump(happiness, save_file); pickle.dump(day, save_file)
        pickle.dump(population_growth, save_file); pickle.dump(food_consumption, save_file)
        for achievment in achievments:
            achievment[2] = []
        pickle.dump(achievments, save_file)
        
def draw_scaled_display(display):
    scaled_display = pygame.transform.scale(display, (int(WINDOW.get_width()), WINDOW.get_height()))
    WINDOW.blit(scaled_display, (0, 0))
    pygame.display.flip()
    
    
def grayscale(surface: pygame.Surface):
    gs_surf = surface.copy()
    width, height = gs_surf.get_size()
    for x in range(width):
        for y in range(height):
            red, green, blue, alpha = gs_surf.get_at((x, y))
            average = (red + green + blue) // 3
            gs_color = (average, average, average, alpha)
            gs_surf.set_at((x, y), gs_color)
    return gs_surf

def add_line_breaks(text: str, max_line_length: int=15):
    char_count = 0
    words = text.split(' ')
    return_words = []
    for word in words:
        char_count += len(word)
        if char_count > max_line_length:
            char_front_dif = max_line_length - (char_count - len(word))
            char_end_dif = char_count - max_line_length
            
            if char_front_dif > char_end_dif:
                return_words.append(word + '\n')
            else:
                return_words.append('\n' + word)
            
            char_count = 0
        
        else:
            return_words.append(word)    
                
    return ' '.join(return_words)
