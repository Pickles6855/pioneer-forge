import pygame
import math
from .const import *
from .buildings import *
from .ui import *

def defender_achievment(wood, stone, food, happiness, population, buildings: list[Building], available_buildings: list[Building]):
    num_of_fortresses = 0
    for building in buildings:
        if type(building) == Fortress:
            num_of_fortresses += 1
    return num_of_fortresses >= 3

def builder_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    matching_buildings = 0
    for building1 in available_buildings:
        for building2 in buildings:
            if building1.name == building2.name:
                matching_buildings += 1
                break
    return matching_buildings >= len(available_buildings)

def wealthy_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return wood >= 1000 and stone >= 1000 and food >= 1000

def happiness_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return happiness >= 100

def hamlet_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return population[0] >= 100

def small_village_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return population[0] >= 300

def large_village_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return population[0] >= 700

def small_city_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return population[0] >= 1500

def large_city_achievment(wood, stone, food, happiness, population, buildings, available_buildings: list[Building]):
    return population[0] >= 3000


def handle_achievments_menu(display: pygame.Surface, mouse_x, mouse_y, events, left_arrrow_button: Button, right_arrow_button: Button, achievments, selected_achievment):
    achievments_overlay = pygame.Surface((WIDTH, HEIGHT))
    achievments_overlay.set_alpha(120)
    achievments_overlay.fill(BLACK)
    display.blit(achievments_overlay, (0, 0))
    
    achievments_menu_text = PUBLIC_PIXEL_FONT.render_text('Achievments', 50, WHITE)
    display.blit(achievments_menu_text, (WIDTH//2 - achievments_menu_text.get_width()//2, 150))
    
    achievments_test_surf = pygame.Surface((WIDTH - 100, HEIGHT - 200))
    achievments_per_row = math.floor(achievments_test_surf.get_width()/ACHIEVMENTS_SIZE[0])
    achievments_surf = pygame.Surface((ACHIEVMENTS_SIZE[0] * achievments_per_row + 10 * achievments_per_row, HEIGHT - 400), pygame.SRCALPHA)
    achievments_surf_pos = (WIDTH//2 - achievments_surf.get_width()//2, 200 + achievments_menu_text.get_height())
    
    current_row = 0
    for indx, achievment in enumerate(achievments):
        if indx % achievments_per_row == 0 and indx > 0:
            current_row += 1
        achievment_pos = (10 * (indx - (current_row * achievments_per_row)) + ACHIEVMENTS_SIZE[0] * (indx - (current_row * achievments_per_row)), current_row * ACHIEVMENTS_SIZE[1] + current_row * 10)
        achievment_img = 0 if achievment[-3] else 1
        achievments_surf.blit(achievment[2][achievment_img], achievment_pos)
        
        achievment_rect = pygame.Rect(achievments_surf_pos[0] + achievment_pos[0], achievments_surf_pos[1] + achievment_pos[1], *ACHIEVMENTS_SIZE)
        # print(achievment_rect.x, achievment_rect.y, achievment_rect.width, achievment_rect.height)
        if achievment_rect.collidepoint(mouse_x, mouse_y):

            # print('clicked', achievment[1], type(achievment[1]))
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    selected_achievment = indx
        if selected_achievment == indx:
            
            achievment_name_text = PUBLIC_PIXEL_FONT.render_text(str(achievment[0]), 30, WHITE)
            display.blit(achievment_name_text, (WIDTH//2 - achievment_name_text.get_width()//2, achievments_surf_pos[1] + achievments_surf.get_height()))
            
            achievment_desc_text = PUBLIC_PIXEL_FONT.render_text(str(achievment[1]), 25, WHITE)
            achievment_desc_text_pos = (WIDTH//2 - achievment_desc_text.get_width()//2, achievments_surf_pos[1] + achievments_surf.get_height() + achievment_name_text.get_height() + 15)
            display.blit(achievment_desc_text, achievment_desc_text_pos)


    display.blit(achievments_surf, achievments_surf_pos)

    return display, selected_achievment

def handle_achievments(display: pygame.Surface, achievments, wood, stone, food, happiness, population, buildings, available_buildings):
    for achievment in achievments:
        if achievment[-1](wood, stone, food, happiness, population, buildings, available_buildings) == True and achievment[-3] == False:
            achievment[-3] = True
            achievment[-2][0] = True
        
        if achievment[-2][0]:
            if achievment[-2][1] > 600 and achievment[-2][2] == 'down':
                achievment[-2][2] =  'up'
            else:
                if achievment[-2][2] == 'down':
                    achievment[-2][1] += 5
                else:
                    achievment[-2][1] -= 5
                
            if achievment[-2][1] < 0:
                achievment[-2][1] = 0
                achievment[-2][0] = False
                
        # Achievment popup
        if achievment[-2][0]:
            achievment_popup_text = PUBLIC_PIXEL_FONT.render_text(add_line_breaks(f'{achievment[0]} Achievment Completed'), 30, WHITE)
            achievment_popup_y = (-10 - achievment_popup_text.get_height()) + (achievment[-2][1] if achievment[-2][1] < achievment_popup_text.get_height() + 30 else achievment_popup_text.get_height() + 30)
            display.blit(achievment_popup_text, (WIDTH//2 - achievment_popup_text.get_width()//2, achievment_popup_y))
                

    return display, achievments