import pygame
from .const import *

def handle_policies_menu(display: pygame.Surface, population_growth, food_consumption, policies_menu, events, change_policies_buttons: list[Button], mouse_x, mouse_y):
    population_growth_plus_button, population_growth_minus_button = change_policies_buttons[0], change_policies_buttons[1]
    food_consumption_plus_button, food_consumption_minus_button = change_policies_buttons[2], change_policies_buttons[3]
    
    for event in events:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE or event.key == pygame.K_w or event.key == pygame.K_a or event.key == pygame.K_s or event.key == pygame.K_d or event.key == pygame.K_RETURN:
                policies_menu = False
                break
    
    # Overlay
    policies_menu_overlay = pygame.Surface((WIDTH, HEIGHT))
    policies_menu_overlay.set_alpha(120)
    policies_menu_overlay.fill(BLACK)
    display.blit(policies_menu_overlay, (0, 0))
    
    # Text
    # Population Growth
    if population_growth == 20:
        population_growth_str = 'Super Fast Growth'
    elif population_growth == 25:
        population_growth_str = 'Fast Growth'
    elif population_growth == 30:
        population_growth_str = 'Regular Growth'
    elif population_growth == 35:
        population_growth_str = 'Slow Growth'
    else:
        population_growth_str = 'No Growth'
        
    population_growth_text = PUBLIC_PIXEL_FONT.render_text(f'Population Growth:  {population_growth_str}', 25, WHITE)
    population_growth_surf_height = BUTTON_SIZE[1]//2 if BUTTON_SIZE[1]//2 > population_growth_text.get_height() else population_growth_text.get_height()
    population_growth_surf = pygame.Surface((population_growth_text.get_width() + 20 + BUTTON_SIZE[0]//2, population_growth_surf_height), pygame.SRCALPHA)
    
    population_growth_surf.blit(population_growth_text, (0, population_growth_surf.get_height()//2 - population_growth_text.get_height()//2))
    
    population_growth_plus_button_pos = (population_growth_text.get_width() + 10, population_growth_surf.get_height()//2 - BUTTON_SIZE[1]//4)
    population_growth_minus_button_pos = (population_growth_surf.get_width() - BUTTON_SIZE[0]//4, population_growth_surf.get_height()//2 - BUTTON_SIZE[1]//4)
    
    population_growth_surf.blit(population_growth_plus_button.display_img, population_growth_plus_button_pos)
    population_growth_surf.blit(population_growth_minus_button.display_img, population_growth_minus_button_pos)
    
    
    
    # Food Consumption
    if food_consumption == 2:
        food_consumption_str = 'Extreme Fasting'
    elif food_consumption == 4:
        food_consumption_str = 'Fasting'
    elif food_consumption == 6:
        food_consumption_str = 'Regular'
    elif food_consumption == 8:
        food_consumption_str = 'Feasting'
    else:
        food_consumption_str = 'Extreme Feasting'
    food_consumption_text = PUBLIC_PIXEL_FONT.render_text(f'Food Consumption:  {food_consumption_str}', 25, WHITE)
    food_consumption_surf_height = BUTTON_SIZE[1]//2 if BUTTON_SIZE[1]//2 > food_consumption_text.get_height() else food_consumption_text.get_height()
    food_consumption_surf = pygame.Surface((food_consumption_text.get_width() + 20 + BUTTON_SIZE[0]//2, food_consumption_surf_height), pygame.SRCALPHA)
    
    food_consumption_surf.blit(food_consumption_text, (0, food_consumption_surf.get_height()//2 - food_consumption_text.get_height()//2))
    
    food_consumption_plus_button_pos = (food_consumption_text.get_width() + 10, food_consumption_surf.get_height()//2 - BUTTON_SIZE[1]//4)
    food_consumption_minus_button_pos = (food_consumption_surf.get_width() - BUTTON_SIZE[0]//4, food_consumption_surf.get_height()//2 - BUTTON_SIZE[1]//4)
    
    food_consumption_surf.blit(food_consumption_plus_button.display_img, food_consumption_plus_button_pos)
    food_consumption_surf.blit(food_consumption_minus_button.display_img, food_consumption_minus_button_pos)
    
    # Policies menu name
    policies_menu_text = PUBLIC_PIXEL_FONT.render_text('Settlement Policies', 40, WHITE)
    
    
    display.blit(policies_menu_text, (WIDTH//2 - policies_menu_text.get_width()//2, 150))
    
    population_growth_surf_pos = (WIDTH//2 - population_growth_surf.get_width()//2, 200 + policies_menu_text.get_height())
    display.blit(population_growth_surf, population_growth_surf_pos)
    
    food_consumption_surf_pos = (WIDTH//2 - food_consumption_surf.get_width()//2, 220 + policies_menu_text.get_height() + population_growth_text.get_height())
    display.blit(food_consumption_surf, food_consumption_surf_pos)
    
    # Update buttons
    # Population Growth
    population_growth_plus_button.rect.x, population_growth_plus_button.rect.y = population_growth_surf_pos[0] + population_growth_plus_button_pos[0], population_growth_surf_pos[1] + population_growth_plus_button_pos[1]
    population_growth_minus_button.rect.x, population_growth_minus_button.rect.y = population_growth_surf_pos[0] + population_growth_minus_button_pos[0], population_growth_surf_pos[1] + population_growth_minus_button_pos[1]
    if population_growth_plus_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if population_growth <= 20:
            population_growth = 40
        else:
            population_growth -= 5
    if population_growth_minus_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if population_growth >= 40:
            population_growth = 20
        else:
            population_growth += 5
            
    # Food Consumption
    food_consumption_plus_button.rect.x, food_consumption_plus_button.rect.y = food_consumption_surf_pos[0] + food_consumption_plus_button_pos[0], food_consumption_surf_pos[1] + food_consumption_plus_button_pos[1]
    food_consumption_minus_button.rect.x, food_consumption_minus_button.rect.y = food_consumption_surf_pos[0] + food_consumption_minus_button_pos[0], food_consumption_surf_pos[1] + food_consumption_minus_button_pos[1]
    if food_consumption_plus_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if food_consumption >= 10:
            food_consumption = 2
        else:
            food_consumption += 2
    if food_consumption_minus_button.update(events, mouse_x=mouse_x, mouse_y=mouse_y) == True:
        if food_consumption <= 0:
            food_consumption = 10
        else:
            food_consumption -= 2
    
    return display, population_growth, food_consumption, policies_menu, [population_growth_plus_button, population_growth_minus_button, food_consumption_plus_button, food_consumption_minus_button]
