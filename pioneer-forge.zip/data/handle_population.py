import pygame
from .const import *
from .buildings import *
from random import randint

def handle_population(population, buildings: list[Building], building_action_event, happiness, food, population_growth, food_consumption, under_attack):
    
    if building_action_event:
        for i in range(population[1]):
            # Reproduction
            if randint(0, population_growth) == 0 and population_growth != 40:
                population[0] += 1
                population[2] += 1
                
            # Death
            death_rate = 80
            if food <= 0:
                death_rate /= 2
            if under_attack:
                death_rate /= 2
            if randint(0, death_rate) == 0:
                population[0] -= 1
                population[1] -= 1
                
        # Children growth
        for i in range(population[2]):
            if randint(0, 40) == 0:
                population[1] += 1
                population[2] -= 1
    
    # Homeless people
    houses = [building for building in buildings if building.building_type == 'housing']
    housing_slots = sum([house.CAPACITY - house.users for house in houses])
    homeless = population[0] - sum([house.users for house in houses])

    if homeless > 0 and housing_slots > 0:
        for house in houses:
            while house.CAPACITY - house.users > 0 and homeless > 0:
                homeless -= 1
                house.users += 1
    
    # Unemployed people
    businesses = [building for building in buildings if building.building_type == 'business']
    job_slots = sum([business.max_workers - business.users for business in businesses])
    unemployed = population[1] - sum([business.users for business in businesses])
    
    # Check for overemployed buildings
    for business in businesses:
        while business.users > business.max_workers:
            business.users -= 1
            unemployed += 1
    
    # Recaculate job slots
    job_slots = sum([business.max_workers - business.users for business in businesses])
    
    # Unemployed people
    if unemployed > 0 and job_slots > 0:
        for business in businesses:
            while business.max_workers - business.users > 0 and unemployed > 0:
                unemployed -= 1
                business.users += 1
        
        
        # Food consumption
        if len(buildings) > 1:
            food_consumed = population[0]//food_consumption
            for i in range(food_consumed):
                if food > 0:
                    food -= 0.1
    
    # Calculate happiness percentage
    homeless_happiness = 1 - homeless/population[0]
    unemployed_happiness = 1 - unemployed/population[1]
    building_happy_points = 0
    for building in buildings:
        capacity = building.CAPACITY if building.building_type == 'housing' else building.max_workers
        building_happy_points += (building.users/(capacity if capacity > 0 else 1)) * building.happy_points
    building_happiness = building_happy_points/sum([building.happy_points for building in buildings])
    food_happiness = 0 if food <= 0 else food_consumption/6
    happiness = int(((homeless_happiness + unemployed_happiness + building_happiness + food_happiness)/4) * 100)
    
    return population, buildings, happiness, int(food)